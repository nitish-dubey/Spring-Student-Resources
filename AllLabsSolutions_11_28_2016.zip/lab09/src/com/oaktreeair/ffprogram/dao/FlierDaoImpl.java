package com.oaktreeair.ffprogram.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.oaktreeair.ffprogram.Flier;

@Repository("flierDao")
public class FlierDaoImpl implements FlierDAO
{
	private JdbcTemplate template;
	private FlierRowMapper mapper;            

	private class FlierRowMapper implements RowMapper<Flier>
	{
		public Flier mapRow(ResultSet rs, int rowNum) throws SQLException
		{
			Flier f = new Flier();

			f.setFlierID(rs.getLong("FlierID"));
			f.setMileageBalance(rs.getInt("MileageBalance"));
			f.setName(rs.getString("Name"));

			return f;
		}
	}

	@Autowired
	public void setDataSource(DataSource ds)
	{
	    template = new JdbcTemplate(ds);
	    mapper = new FlierRowMapper();		
	}
	
	@Override
	@Transactional(propagation = Propagation.MANDATORY)
	public Flier findFlierByID(Long flierID)
	{
		return template.queryForObject("SELECT * FROM Flier WHERE flierID=?",
				mapper, flierID);
	}

	@Override
	@Transactional(propagation = Propagation.MANDATORY)
	public void updateFlier(Flier flier)
	{
		template.update("UPDATE Flier SET MileageBalance=?, Name=?",
				flier.getMileageBalance(), flier.getName());
	}

}
