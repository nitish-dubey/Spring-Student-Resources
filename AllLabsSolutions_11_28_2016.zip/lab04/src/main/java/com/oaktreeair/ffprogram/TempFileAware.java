package com.oaktreeair.ffprogram;

import java.io.File;

public interface TempFileAware
{
	void setTempFile(File temp);
}
