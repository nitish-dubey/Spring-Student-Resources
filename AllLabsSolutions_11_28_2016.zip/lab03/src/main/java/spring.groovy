import com.bigbank.domain.Loan

beans {
  loan02 (Loan) {
     amount = 123.45
     loanID = 2
     propertyAddress = "764 Pine Court"
     purchasePrice = 45678
  }
}