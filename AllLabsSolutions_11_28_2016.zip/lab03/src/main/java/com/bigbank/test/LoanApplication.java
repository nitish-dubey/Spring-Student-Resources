package com.bigbank.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.bigbank.configuration.LoanManagerConfig;
import com.bigbank.domain.Borrower;
import com.bigbank.domain.Loan;
import com.bigbank.domain.LoanManager;

public class LoanApplication
{
	public static void main(String[] args)
	{
    	AnnotationConfigApplicationContext ctx =
        		new AnnotationConfigApplicationContext(
        			     LoanManagerConfig.class);        
        
        LoanManager lm = (LoanManager)ctx.getBean("loanManager");
        
        Borrower b = (Borrower)ctx.getBean("borrower01");
        
        lm.applyForLoan(b);
        
//        Loan loan02 = (Loan)ctx.getBean("loan02");
//        System.out.println(loan02);
        
        ctx.close();
	}
}
