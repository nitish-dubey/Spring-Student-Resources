package com.bigbank.services;

import java.util.Random;

import com.bigbank.domain.Borrower;

public class LoanServiceImpl implements LoanService
{

	@Override
	public boolean processLoan(Borrower b)
	{
		boolean retVal = true;
		b.getTheLoan().setStatus("Approved");
		
		Random rand = new Random();
		int threshold = rand.nextInt(30000);
		
		System.out.printf("Threshold %d Amount %d%n", threshold,
				b.getTheLoan().getAmount());
		
		if(b.getTheLoan().getAmount() >
		   b.getTheLoan().getPurchasePrice() ||
		   b.getTheLoan().getAmount() > threshold)
		{
			retVal = false;
			b.getTheLoan().setStatus("Rejected");
		}
		
		return retVal;
	}
}
