package com.lq;

public class TraditionalGreetingsTest {
	public static void main(String[] args) {
		
		Greeter greeter = new FrenchGreeter();
		greeter.greet();
	}
}
