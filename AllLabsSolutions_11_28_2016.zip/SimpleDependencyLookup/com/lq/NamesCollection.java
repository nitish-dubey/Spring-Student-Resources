package com.lq;

import java.util.Collection;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class NamesCollection {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = 
			new ClassPathXmlApplicationContext("greetings.xml");
		Collection<String> names = 
				(Collection<String>)context.getBean("collection");
		names.add("alice");
		names.add("john");
		names.add("christina");
		names.add("karl");
		names.add("karl"); // karl is added twice
		names.add("mark");
		names.add("lauren");
		System.out.println(names);
	}
}
