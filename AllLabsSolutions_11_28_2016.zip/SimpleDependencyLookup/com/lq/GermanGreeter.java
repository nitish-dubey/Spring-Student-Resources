package com.lq;

public class GermanGreeter implements Greeter {
	public void greet() {
		System.out.println("Hallo Welt");
	}

	//@Override
	public String toString() {
		return "GermanGreeter [toString()=" + super.toString() + "]";
	}
}



