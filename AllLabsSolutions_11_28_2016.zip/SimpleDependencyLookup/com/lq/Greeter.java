package com.lq;

public interface Greeter {
	public void greet();
}

