package com.lq;

public class EnglishGreeter implements Greeter {
	public void greet() {
		System.out.println("Hello World");
	}
}



