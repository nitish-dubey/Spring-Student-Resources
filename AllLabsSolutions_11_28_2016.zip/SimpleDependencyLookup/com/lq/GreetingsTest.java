package com.lq;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class GreetingsTest {
	
	static Logger log = Logger.getLogger(GreetingsTest.class.getName());
	public static void main(String[] args) {
		ApplicationContext context = 
			new ClassPathXmlApplicationContext("greetings.xml");
		//log.info("Creating Greeter Obj");
		Greeter greeter = (Greeter)context.getBean("greeter");
		greeter.greet();
		//log.info("Leaving GreetingsTest");
	}
}
