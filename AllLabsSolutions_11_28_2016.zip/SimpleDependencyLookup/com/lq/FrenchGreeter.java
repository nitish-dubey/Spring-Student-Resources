package com.lq;

public class FrenchGreeter implements Greeter {
	
	
	public void greet() {
		System.out.println("Bonjour tout le monde");
	}
}



