package com.lq.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;

public class MainApp {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(
				HelloWorld.class);
		// or for multiple config classes
		// new AnnotationConfigApplicationContext();
		// ctx.register(HelloWorld.class, OtherConfig.class);
		// ctx.register(AdditionalConfig.class);
		// ctx.refresh();
		// see also:
		// http://www.tutorialspoint.com/spring/spring_java_based_configuration.htm

		HelloWorld helloWorld = ctx.getBean(HelloWorld.class);

		helloWorld.setMessage("Hello World!");
		helloWorld.getMessage();
	}
}