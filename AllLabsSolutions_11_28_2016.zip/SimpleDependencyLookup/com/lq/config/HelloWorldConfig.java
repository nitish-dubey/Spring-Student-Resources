package com.lq.config;
import org.springframework.context.annotation.*;
// Below equivalent to:
//<beans ...>
//	<bean id="helloWorld" class="com.tutorialspoint.HelloWorld" />
//</beans>
@Configuration
public class HelloWorldConfig {

   @Bean 
   // @Scope("prototype")
   public HelloWorld helloWorld(){
      return new HelloWorld();
   }
}