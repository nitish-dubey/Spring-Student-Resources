package com.oaktreeair.ffprogram;

import java.util.Collection;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Component;

@Component("calcBonus")
public class BonusCalcImpl implements BonusCalc
{

    @Override
    public int calcBonus(Flier flier, Segment seg)
    {
    	try
    	{
    	    double d = Math.random();
    	    int time = (int)(d * 1000);
    	    TimeUnit.MILLISECONDS.sleep(time);
    	}
    	catch (InterruptedException e) {}
    	
    	
        double bonus = 0;
        
        switch(flier.getLevel())
        {
            case Member:
                bonus = seg.getMiles() * 0.10;
                break;
            case Gold:
                bonus = seg.getMiles() * 0.25;
                break;
            case Platinum:
                bonus = seg.getMiles() * 0.50;
                break;
        }
        
        return (int)bonus;
    }

    @Override
    public int calcBonus(Flier flier, Collection<Segment> segments)
    {
    	try
    	{
    	    double d = Math.random();
    	    int time = (int)(d * 1000);
    	    TimeUnit.MILLISECONDS.sleep(time);
    	}
    	catch (InterruptedException e) {}
    	
    	
        double bonus = 0;        
        Flier.Level level = flier.getLevel();
        
        for(Segment seg : segments)
        {
            switch(level)
            {
                case Member:
                    bonus += seg.getMiles() * 0.10;
                    break;
                case Gold:
                    bonus += seg.getMiles() * 0.25;
                    break;
                case Platinum:
                    bonus += seg.getMiles() * 0.50;
                    break;
            }            
        }
        
        return (int)bonus;
    }

}
