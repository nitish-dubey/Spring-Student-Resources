package com.oaktreeair.test;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.oaktreeair.ffprogram.BonusCalc;
import com.oaktreeair.ffprogram.BonusCalcImpl;
import com.oaktreeair.ffprogram.ContactInfo;
import com.oaktreeair.ffprogram.Flier;
import com.oaktreeair.ffprogram.Segment;
import com.oaktreeair.ffprogram.Flier.Level;

@Configuration
public class FrequentFlierConfig
{
	@Bean(name="seg01")
	public Segment getSeg01()
	{
		Segment seg = new Segment();
		seg.setFlightNumber(2238);
		seg.setMiles(1000);
		seg.setOriginatingCity("ORD");
		seg.setSegmentNumber(1234L);
		
		return seg;
	}
	
	@Bean(name="contact01")
	public ContactInfo getContact01()
	{
		ContactInfo ci = new ContactInfo();
		ci.setEmailAddress("sam@sam.com");
		ci.setHomePhone("555-1212");
		ci.setMobilePhone("555-1313");
		ci.setSmsNumber("555-1515");
				
		return ci;	
	}
	
	@Bean(name="calcBonus")
	public BonusCalc getCalcBonus()
	{
		return new BonusCalcImpl();
	}
	
	@Bean(name="flier01")
	public Flier getFlier01()
	{
		Flier f = new Flier();
		f.setFlierID(1234L);
		f.setFlierName("Sam Jones");
		f.setLevel(Level.Platinum);
		f.setContactInfo(getContact01());
		
		return f;
	}
}
