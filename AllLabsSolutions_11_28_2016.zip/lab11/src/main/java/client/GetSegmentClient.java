package client;

import java.net.URL;


import oracle.xml.parser.v2.DOMParser;


import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



public class GetSegmentClient {

	static void printElements(Document doc) {
		System.out.print("The elements are: ");
		NodeList nl = doc.getElementsByTagName("*");
		Node n;
		for (int i = 1; i < nl.getLength(); i++) {
			n = nl.item(i);
			System.out.print("\n" + n.getNodeName() + " ");
			System.out.print(n.getChildNodes().item(0).getTextContent());
		}
		System.out.println();
	}

	public static void main(String[] args) throws Exception {
		URL url = new URL("http://localhost:8080/lab11/rest/segment/12");
		DOMParser parser = new DOMParser();
		parser.parse(url);
		printElements(parser.getDocument());
	}
}