package client;

import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.oaktreeair.ffprogram.Segment;

public class GetSegmentsClient {

	public static void main(String[] args) throws Exception {
		URL url = new URL("http://localhost:8080/lab11/rest/segment");
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.connect();

		// Dates are wonky in JSON have to use Deserializer to get long value for the date
		Gson gson = new GsonBuilder().registerTypeAdapter(Date.class,
				new JsonDeserializer<Date>() {
					public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) 
							throws JsonParseException {
						return json == null ? null : new Date(json.getAsLong());
					}
				}).create();
		
		Segment[] seg = gson.fromJson(new InputStreamReader(conn.getInputStream()), Segment[].class);
		
		for (Segment segment : seg) System.out.println(segment);

		conn.disconnect();
	}
	
	// JsonDeserializer<Date> deser = new JsonDeserializer<Date>() {
	// @Override
	// public Date deserialize(JsonElement json, Type typeOfT,
	// JsonDeserializationContext context)
	// throws JsonParseException {
	// return json == null ? null : new Date(json.getAsLong());
	// }
	// };
	
	//BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	
}