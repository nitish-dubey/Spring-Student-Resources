package com.oaktreeair.ffprogram.controllers;

import java.util.List;
import java.util.Random;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.oaktreeair.ffprogram.Segment;

@Controller
@RequestMapping("rest")
public class SegmentController
{
	@Autowired
	private ServletContext servletCtx;
	
	@SuppressWarnings("serial")
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	private class ResourceNotFoundException 
	   extends RuntimeException
	{
	}             

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/segment/{segmentNumber}", method = RequestMethod.GET)
	public @ResponseBody
	Segment getSegment(@PathVariable("segmentNumber") int segNum)
	{
		Segment retVal = null;

		List<Segment> segments = (List<Segment>) servletCtx
				.getAttribute("segments");

		for (Segment s : segments)
		{
			if (s.getSegmentNumber() == segNum)
			{
				retVal = s;
				break;
			}
		}

		if (retVal == null)
			throw new ResourceNotFoundException();

		return retVal;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/segment", method = RequestMethod.GET)
	public @ResponseBody
	List<Segment> getSegments()
	{
		List<Segment> segments = (List<Segment>) servletCtx
				.getAttribute("segments");

		return segments;
	}

	// curl -v -X POST -H "Content-type: application/json" -d "{\"segmentNumber\":0,\"flightNumber\":666,\"originatingCity\":\"DCA\", \"segmentDate\":\"2014-7-8\", \"miles\": 987}" http://localhost:9081/Lab24Web/rest/segment
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/segment", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public @ResponseBody
	Segment createSegment(@RequestBody Segment s, HttpServletResponse response)
	{
		Random r = new Random();
		Long newID = (long) (r.nextFloat() * 1000000);

		List<Segment> segments = (List<Segment>) servletCtx
				.getAttribute("segments");

		s.setSegmentNumber(newID);
		segments.add(s);

		response.setHeader("Location", "/segment/" + newID);
		return s;
	}

	// curl -v -X PUT -H "Content-Type: application/json"  -d "{\"segmentNumber\":12,\"flightNumber\":666,\"originatingCity\":\"DCA\", \"segmentDate\":\"2014-7-8\", \"miles\": 6666}" http://localhost:9081/Lab24Web/rest/segment/12
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/segment/{segmentNumber}", method = RequestMethod.PUT)
	public ResponseEntity<String> putSegment(
			@PathVariable("segmentNumber") long segNum,
			@RequestBody Segment theSeg)
	{
		ResponseEntity<String> retVal = new ResponseEntity<String>(
				HttpStatus.NO_CONTENT);

		List<Segment> segments = (List<Segment>) servletCtx
				.getAttribute("segments");

		Segment found = null;
		for (Segment s : segments)
		{
			if (s.getSegmentNumber() == segNum)
			{
				found = s;
				break;
			}
		}

		if (found == null)
			throw new ResourceNotFoundException();

		found.setFlightNumber(theSeg.getFlightNumber());
		found.setMiles(theSeg.getMiles());
		found.setOriginatingCity(theSeg.getOriginatingCity());
		found.setSegmentDate(theSeg.getSegmentDate());

		return retVal;
	}

	// curl -v -X DELETE http://localhost:9081/Lab24Web/rest/segment/12
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/segment/{segmentNumber}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteSegment(
			@PathVariable("segmentNumber") long segNum)
	{
		ResponseEntity<String> retVal = new ResponseEntity<String>(
				HttpStatus.NO_CONTENT);

		List<Segment> segments = (List<Segment>) servletCtx
				.getAttribute("segments");

		Segment found = null;
		for (Segment s : segments)
		{
			if (s.getSegmentNumber() == segNum)
			{
				found = s;
				break;
			}
		}

		if (found == null)
			throw new ResourceNotFoundException();
		
		segments.remove(found);
		
		return retVal;
	}

}
