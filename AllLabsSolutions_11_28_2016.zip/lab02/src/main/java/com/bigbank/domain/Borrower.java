package com.bigbank.domain;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("borrower01")
public class Borrower
{
	@Value("4567")
	private int borrowerID;
	@Value("Paul Westerberg")
	private String name;
	@Value("463 Ash Street Minneapolis, MN")
	private String address;
	@Value("602-555-1212")
	private String phone;

	@Resource(name="loan01")
	private Loan theLoan;

	public int getBorrowerID()
	{
		return borrowerID;
	}

	public void setBorrowerID(int borrowerID)
	{
		this.borrowerID = borrowerID;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getAddress()
	{
		return address;
	}

	public void setAddress(String address)
	{
		this.address = address;
	}

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	public Loan getTheLoan()
	{
		return theLoan;
	}

	public void setTheLoan(Loan theLoan)
	{
		this.theLoan = theLoan;
	}

}
