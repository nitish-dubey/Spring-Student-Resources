package com.bigbank.test;

import java.util.logging.Logger;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.bigbank.domain.Borrower;
import com.bigbank.domain.LoanManager;

public class LoanApplication
{
	static Logger log = Logger.getLogger(LoanApplication.class.getName());
	public static void main(String[] args)
	{
        AbstractApplicationContext ctx = 
                new FileSystemXmlApplicationContext("src/main/java/spring.xml");
        
        log.info("Going to create LoanManager Obj");

        LoanManager lm = (LoanManager)ctx.getBean("loanManager");
        
        Borrower b = (Borrower)ctx.getBean("borrower01");
        
        lm.applyForLoan(b);
        
        ctx.close();
	}
}
