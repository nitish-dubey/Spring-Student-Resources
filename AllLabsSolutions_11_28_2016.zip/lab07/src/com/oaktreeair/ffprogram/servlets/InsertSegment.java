package com.oaktreeair.ffprogram.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.oaktreeair.ffprogram.Segment;
import com.oaktreeair.ffprogram.dao.SegmentDao;

@WebServlet("/InsertSegment")
public class InsertSegment extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException
	{
		ServletContext servletContext = getServletContext();
		WebApplicationContext ctx = WebApplicationContextUtils
				.getRequiredWebApplicationContext(servletContext);

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

		SegmentDao dao = (SegmentDao) ctx.getBean("segmentDao");

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		try
		{
			int miles = Integer.parseInt(request.getParameter("miles"));
			Date segmentDate = df.parse(request.getParameter("segmentDate"));
			int flightNumber = Integer
					.parseInt(request.getParameter("flightNumber"));

			Segment segment = new Segment();
			segment.setFlightNumber(flightNumber);
			segment.setMiles(miles);
			segment.setOriginatingCity(request.getParameter("originatingCity"));
			segment.setSegmentDate(segmentDate);

			System.out.println("Segment to insert: " + segment);

			int segmentNumber = dao.insertSegment(segment);
			out.println("Segment inserted, segment number: " + segmentNumber);
		}
		catch (Exception e)
		{
			out.println("Data input error, please try again");
		}

	}
}