package com.oaktreeair.ffprogram.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.oaktreeair.ffprogram.Segment;
import com.oaktreeair.ffprogram.dao.SegmentDao;

@WebServlet("/DisplayAllSegments")
public class DisplayAllSegments extends HttpServlet
{
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
        ServletContext servletContext = getServletContext();
        WebApplicationContext ctx = WebApplicationContextUtils
                .getRequiredWebApplicationContext(servletContext);

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

        SegmentDao dao = (SegmentDao) ctx.getBean("segmentDao");

        Collection<Segment> segments = dao.findAllSegments();

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><body>");
        out.println("<table border='1'>");
        out.println("<tr>");
        out.println("<th>Segment Number</th>");
        out.println("<th>Segment Date</th>");
        out.println("<th>Flight Number</th>");
        out.println("<th>Originating City</th>");
        out.println("<th>Miles</th>");
        out.println("</tr>");

        for (Segment seg : segments)
        {
            out.println("<tr>");

            out.println("<td>" + seg.getSegmentNumber() + "</td>");
            out.println("<td>" + df.format(seg.getSegmentDate()) + "</td>");
            out.println("<td>" + seg.getFlightNumber() + "</td>");
            out.println("<td>" + seg.getOriginatingCity() + "</td>");
            out.println("<td>" + seg.getMiles() + "</td>");

            out.println("</tr>");
        }

        out.println("</table>");
        out.println("</body></html>");
    }

}
