package com.oaktreeair.ffprogram.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.oaktreeair.ffprogram.Segment;

@Repository("segmentDao")
public class SegmentDaoImpl implements SegmentDao
{
	public class SegmentRowMapper implements RowMapper<Segment>
	{
		public Segment mapRow(ResultSet rs, int rowNum) throws SQLException
		{
			Segment seg = new Segment();
			
			seg.setFlightNumber(rs.getInt("FlightNumber"));
			seg.setSegmentNumber(rs.getLong("SegmentNumber"));			
			seg.setSegmentDate(rs.getDate("SegmentDate"));			
			seg.setOriginatingCity(rs.getString("OrigCity"));			
			seg.setMiles(rs.getInt("Miles"));						
			
			return seg;
		}
	}

	private JdbcTemplate template;
	private SegmentRowMapper mapper;
    private DataSource segmentDataSource;

	@Autowired
	public void setDataSource(DataSource ds)
	{
		template = new JdbcTemplate(ds);
		mapper = new SegmentRowMapper();
		segmentDataSource = ds;
	}

	@Override
	public int getSegmentCount()
	{
		int count = template.queryForObject("SELECT COUNT(*) FROM Segment",
				Integer.class);
		return count;
	}

	@Override
	public Collection<Segment> findAllSegments()
	{
		List<Segment> segments = template.query(
		        "SELECT * FROM Segment", mapper);

		return segments;
	}

	@Override
	public int insertSegment(Segment s)
	{
        SimpleJdbcInsert inserter = new SimpleJdbcInsert(segmentDataSource);
        inserter.setTableName("segment");
        inserter.usingGeneratedKeyColumns("SegmentNumber");
        Map<String, Object> parms = new HashMap<String, Object>();
        parms.put("FlightNumber", s.getFlightNumber());
        parms.put("Miles", s.getMiles());
        parms.put("OrigCity", s.getOriginatingCity());
        parms.put("SegmentDate", s.getSegmentDate());

        Number id = inserter.executeAndReturnKey(parms);
        return id.intValue();
	}

}
