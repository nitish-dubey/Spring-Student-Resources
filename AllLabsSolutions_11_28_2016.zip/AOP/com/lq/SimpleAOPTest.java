package com.lq;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SimpleAOPTest {
	public static void main(String[] args) throws Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"aop.xml");
		Account account = (Account) context.getBean("account");
		account.debit(500);
		System.out.printf("%.2f%n",account.getBalance());
		account.credit(300);
		System.out.printf("%.2f%n",account.getBalance());
	}
}
