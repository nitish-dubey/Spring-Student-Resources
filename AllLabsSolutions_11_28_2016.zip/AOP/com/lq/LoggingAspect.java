package com.lq;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
@Component
@Aspect
public class LoggingAspect {
// an example of an inline pointcut
@Around("execution(* com.lq.Account.*(..))") 
	public Object log(ProceedingJoinPoint pjp) throws Throwable{
		String className = pjp.getTarget().getClass().getName();
		Logger logger = Logger.getLogger(className);
		String method = pjp.getSignature().toLongString();
		logger.log(Level.INFO, "Before method -- "+method);
		Object returnValue = pjp.proceed();
		logger.log(Level.INFO, "After method -- "+method);
		return returnValue;
	}
}
