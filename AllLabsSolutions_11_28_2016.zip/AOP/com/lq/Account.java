package com.lq;

import org.springframework.stereotype.Component;

@Component
public class Account {
	private double balance = 1000;
	
	public double debit(double amount){
		balance -= amount;
		return balance;
	}
	public double credit(double amount){
		balance += amount;
		return balance;
	}
	public double getBalance() {
		return balance;
	}
}
