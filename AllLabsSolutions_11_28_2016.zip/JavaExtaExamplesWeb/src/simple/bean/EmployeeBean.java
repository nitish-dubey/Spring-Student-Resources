package simple.bean;
public class EmployeeBean
{
    private String firstName = "";
    private String middleName = "";
    private String lastName = "";
    private String employeeNumber = "";
	/**
	 * Returns the employeeNumber.
	 * @return String
	 */
	public String getEmployeeNumber()
	{
		return employeeNumber;
	}

	/**
	 * Returns the firstName.
	 * @return String
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * Returns the lastName.
	 * @return String
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * Returns the middleName.
	 * @return String
	 */
	public String getMiddleName()
	{
		return middleName;
	}

	/**
	 * Sets the employeeNumber.
	 * @param employeeNumber The employeeNumber to set
	 */
	public void setEmployeeNumber(String employeeNumber)
	{
		this.employeeNumber = employeeNumber;
	}

	/**
	 * Sets the firstName.
	 * @param firstName The firstName to set
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * Sets the lastName.
	 * @param lastName The lastName to set
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	/**
	 * Sets the middleName.
	 * @param middleName The middleName to set
	 */
	public void setMiddleName(String middleName)
	{
		this.middleName = middleName;
	}
}
