package simple.bean;
public class MissingInputException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Constructor for MissingInputException.
	 */
	public MissingInputException()
	{
		super();
	}
	/**
	 * Constructor for MissingInputException.
	 * Passing parameter s
	 */
	public MissingInputException(String s)
	{
		super(s);
	}
}
