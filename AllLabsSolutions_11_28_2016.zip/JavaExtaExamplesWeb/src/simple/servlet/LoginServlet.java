package simple.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

public class LoginServlet extends HttpServlet {
	/**
	 *  
	 */
	private static final long serialVersionUID = 1L;

	private Connection conn;

	private DataSource ds;

	private PreparedStatement ps;

	private static final String CONTENT_TYPE = "text/html";

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		try {
			Context ic = new InitialContext();
			ds = (DataSource) ic.lookup("jdbc/cloudscapeDS");
			conn = ds.getConnection();
			//Create a query to find all project for an employee
			//	  String driverName = "com.ibm.db2j.jdbc.DB2jDriver";
			//	  String databaseURL = "jdbc:db2j:C:/rad6workspace/DB/USERDB";
			//
			//	  Class.forName(driverName);
			//
			//      //Generate connection
			//	  conn = DriverManager.getConnection(databaseURL,"","");

			ps = conn.prepareStatement("SELECT * " + "FROM  training.users "
					+ "WHERE userid = ?");
		}
		//    catch (ClassNotFoundException ne)
		//    {
		//      ne.printStackTrace();
		//    }
		catch (SQLException se) {
			se.printStackTrace();
		} catch (NamingException se) {
			se.printStackTrace();
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType(CONTENT_TYPE);
		PrintWriter out = response.getWriter();
		String servleturi = request.getRequestURI();
		String cookievalue = null;
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equals("LoginCookie")) {
					cookievalue = cookies[i].getValue();
					break;
				}
			}
		}
		if (cookievalue == null) {
			out.println("<html>");
			out.println("<head><title>Login to Project Search</title></head>");
			out
					.println("<link rel=stylesheet href=\"css/oracle.css\" media=\"screen\"/>");
			out
					.println("<body>"
							+ "<form method=\"post\" "
							+ "action="
							+ servleturi
							+ ">"
							+ "<h1 align=\"center\">Welcome to the Project Search Application </h1>"
							+ "<div align=\"center\">"
							+ "<p>&nbsp;</p><p>&nbsp;</p>"
							+ "<table border=0><tr><td><h4>User Id:</h4></td>"
							+ "<td><input type=\"text\" name=\"usrId\"></td></tr>"
							+ "<tr><td><h4>User Name:</h4></td>"
							+ "<td><input type=\"text\" name=\"usrName\"></td></tr>"
							+ "</table><p>"
							+ "<input type=\"submit\" name=\"Submit\" value=\"Login\">"
							+ "<input type=\"reset\" name=\"Reset\" value=\"Reset\">"
							+ "</p></div></form>");
			out.println("</body></html>");
		} else {
			out.println("Hello " + cookievalue + ": Welcome back to Users!");
		}
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType(CONTENT_TYPE);
		PrintWriter out = response.getWriter();
		int id = Integer.parseInt(request.getParameter("usrId"));
		String name = request.getParameter("usrName");
		Cookie cookie = new Cookie("LoginCookie", name);
		cookie.setMaxAge(30);
		response.addCookie(cookie);
		out.println("<html>");
		out.println("<body>");
		try {
			if (verifyUser(conn, id)) {
				out.println("User id " + id + " has logged in.");
			} else {
				out.println("Invalid login.  Please try again.");
			}
			out.println("</body></html>");
			out.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}

	public synchronized boolean verifyUser(Connection conn, int id)
			throws SQLException {
		int custid = 0;
		Statement stmt = conn.createStatement();
		// Create a query to find the customer id and last name for this
		// customer
		String verifyquery = "select userid, lastname from training.users "
				+ "where userid =" + id;

		// Execute the query and save all results in a result set object
		ResultSet rs = stmt.executeQuery(verifyquery);

		// Iterate throught the result set object
		while (rs.next()) {
			custid = rs.getInt(1);
		}

		// Close the result set object
		rs.close();

		if (custid != 0) {
			return true;
		} else {
			return false;
		}
	}

	public void destroy() {
		super.destroy();
		try {
			// Close the prepared statement object
			ps.close();

			// Close the connection object
			conn.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
}