package simple.servlet;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;


public class InitServlet extends HttpServlet 
{
  private static final String CONTENT_TYPE = "text/html; charset=windows-1252";
  private String message;

  public void init(ServletConfig config) throws ServletException
  {
    super.init(config);
    message = config.getInitParameter("message");
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    response.setContentType(CONTENT_TYPE);
//    synchronized(this){
//    	
//    }
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>InitServlet</title></head>");
    out.println("<body>");
    out.println("<p>The initialization parameter value follows:</p>");
    out.println(message);
    out.println("</body></html>");
    out.close();
  }
}