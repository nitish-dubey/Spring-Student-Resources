package simple.servlet;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.PrintWriter;
import java.io.IOException;

public class Servlet2 extends HttpServlet 
{
  /**
	 * 
	 */
  private static final long serialVersionUID = 1L;
  private static final String CONTENT_TYPE = "text/html; charset=windows-1252";

  public void init(ServletConfig config) throws ServletException
  {
    super.init(config);
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Servlet Two ServletContext Example</title></head>");
    out.println("<body>");
    out.println("<p>flavor is " + this.getServletContext().getAttribute("flavor") + "</p>");
    out.println("</body></html>");
    out.close();
  }
}