package simple.servlet;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class DemoHelloWorld extends HttpServlet 
{
  private static final String CONTENT_TYPE = "text/html";
  public void init(ServletConfig config) throws ServletException
  {
    super.init(config);
  }
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {

    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>DemoHelloWorld</title></head>");
    out.println("<body>");
    String name = request.getParameter("firstName");
    if ((name != null) && (name.length() > 0)) 
      out.println ("Hello: " + name + "  How are you?");
    else
      out.println ("Hello Anonymous!"); 
    out.println("</body></html>");
    out.close();
  }
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
  	doPost( request,  response);
  }
}




