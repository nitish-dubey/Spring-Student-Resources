package simple.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RequestServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		resp.setContentType("text/html");
		java.io.PrintWriter out = resp.getWriter();

		java.util.Enumeration paramNames = req.getParameterNames();
		out
				.println("***************REQUEST PARAMETERS*********************<BR>");
		while (paramNames.hasMoreElements()) {
			String name = (String) paramNames.nextElement();
			String value = req.getParameter(name);
			out.println(name + " : " + value + "<BR>");
		}

		java.util.Enumeration locales = req.getLocales();
		out.println("*****************LOCALES****************<BR>");
		while (locales.hasMoreElements()) {
			java.util.Locale locale = (java.util.Locale) locales.nextElement();
			out.println(locale + "<BR>");
		}

		out.println("****HEADER INFORMATION****************<BR>");
		java.util.Enumeration headerNames = req.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String name = (String) headerNames.nextElement();
			String value = req.getHeader(name);
			out.println(name + " : " + value + "<BR>");
		}

		out.println("MISCELLANEOUS INFORMATION**************<BR>");
		String charEncoding = req.getCharacterEncoding();
		out.println("Character Encoding: " + charEncoding + "<BR>");
		int contentLength = req.getContentLength();
		out.println("Content Length: " + contentLength + "<BR>");
		String contentType = req.getContentType();
		out.println("Content Type:  " + contentType + "<BR>");

		String protocol = req.getProtocol();
		out.println("Protocol: " + protocol + "<BR>");
		String address = req.getRemoteAddr();
		out.println("Remote Address: " + address + "<BR>");
		String scheme = req.getScheme();
		out.println("Scheme: " + scheme + "<BR>");
		String serverName = req.getServerName();
		out.println("Server Name: " + serverName + "<BR>");
		int serverPort = req.getServerPort();
		out.println("Server Port: " + serverPort + "<BR>");
		boolean secure = req.isSecure();
		out.println("Is secure: " + secure + "<BR>");

	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}
	
	

}