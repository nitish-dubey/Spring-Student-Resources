/*
 * Created on Mar 5, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package simple.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Vector;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import simple.bean.Employee;

/**
 * @author wasadmin
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ListEmployees extends HttpServlet {
	
	private static Connection conn = null;

	/**
	 * Constructor of the object.
	 */
	public ListEmployees() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
		try{conn.close();
		}catch (Exception ex) {
	        //throw new ServletException("Error while cleaning up", ex);
	    }
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
		java.sql.ResultSet resultSet = null;
		java.sql.Statement statement = null;
		Vector employees = null;
		try {
		    //Get database connection from data source
			synchronized (conn){
			    statement = conn.createStatement();
//			    resultSet = statement.executeQuery("SELECT * from EMPLOYEE");
			    resultSet = statement.executeQuery("select * from SAMP.EMPLOYEE");
			    
			
			    employees = new Vector();
			    while (resultSet.next()) {
			        final Employee eachEmployee = new Employee();
			        //eachEmployee.setFirstName(resultSet.getString("FIRSTNME"));
			        eachEmployee.setFirstName(resultSet.getString("FIRSTNME"));
			        eachEmployee.setLastName(resultSet.getString("LASTNAME"));
			        eachEmployee.setMiddleName(resultSet.getString("MIDINIT"));
			        eachEmployee.setEmployeeNo(resultSet.getString("EMPNO"));
			        //Add the employee to the list
			        employees.add(eachEmployee);
			    }
			}

				//Store the list in the request context.
		    request.setAttribute("employees", employees);
		    //Invoke the JSP
		    request.getRequestDispatcher("/newlist_employees.jsp").forward(
		        request,
		        response);
		} catch (Throwable ex) {
		    throw new ServletException(ex);
		} finally {
		    try {
		        if (resultSet != null)
		            resultSet.close();
		        if (statement != null)
		            statement.close();
		        //if (conn != null) conn.close();
		    } catch (Exception ex) {
		        throw new ServletException("Error while cleaning up", ex);
		    }
		}
	
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occure
	 */
	public void init() throws ServletException {
		try {
//			String driverName = "com.ibm.db2j.jdbc.DB2jDriver";
//			String databaseURL = "jdbc:db2j:C:/USERDB";
			String driverName = "org.apache.derby.jdbc.EmbeddedDriver";
			String databaseURL = "jdbc:derby:C:/workspaces/samp";

//			InitialContext ctx = new InitialContext();
//			DataSource ds = (DataSource)ctx.lookup("/jdbc/cloudscapeDS");
//			conn = ds.getConnection();
//			
			Class.forName(driverName);

			//Generate connection
			conn = DriverManager.getConnection(databaseURL,"","");
		} catch (Exception ex) {
			throw new ServletException("Unable to initialize sevlet", ex);
		}// Put your code here
	}

}






