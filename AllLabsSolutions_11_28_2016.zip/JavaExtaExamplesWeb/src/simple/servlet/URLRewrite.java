package simple.servlet;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.PrintWriter;
import java.io.IOException;

public class URLRewrite extends HttpServlet 
{
  /**
	 * 
	 */
  private static final long serialVersionUID = 1L;
  private static final String CONTENT_TYPE = "text/html; charset=windows-1252";

  public void init(ServletConfig config) throws ServletException
  {
    super.init(config);
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    HttpSession session = request.getSession(true);
    session.setAttribute("NAME", "JavaJill");
    out.println("<html>");
    out.println("<head><title>URLRewrite</title></head>");
    out.println("<h2>Test URL Rewriting</h2>");
    out.println("<body>");
    out.println("<table>");
    out.println("<tr><td>Session Id: " + session.getId() + "</td></tr>");
    out.println("<tr><td>Requested session ID from URL: " + request.isRequestedSessionIdFromURL() + "</td></tr>");
    out.println("<tr><td>Requested session ID from cookie: " + request.isRequestedSessionIdFromCookie() + "</td></tr>");
    out.println("<tr><td>Value of NAME: " + session.getAttribute("NAME") + "</td></tr>");
    out.println("<tr><td>URI: " + request.getRequestURI() + "</td></tr>");
    out.println("<tr><td>encoded URI: " + response.encodeURL(request.getRequestURI()) + "</td></tr>");
    out.println("<tr><td>Click <a href=\"" + response.encodeURL(request.getRequestURI()) + "\">here</a>");
    out.println(" to test session tracking. </td></tr>");
    out.println("</table></body></html>");
    out.close();
  }
}