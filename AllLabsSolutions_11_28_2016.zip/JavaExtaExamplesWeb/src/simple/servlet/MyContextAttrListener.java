package simple.servlet;
import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class MyContextAttrListener implements ServletContextAttributeListener, ServletContextListener ,HttpSessionListener, HttpSessionAttributeListener
{
  public MyContextAttrListener()
  {
  }

  public void attributeAdded(ServletContextAttributeEvent p0)
  {
	  String message = "Attribute added name is: " + p0.getName() + " value is: " + p0.getValue().toString();
	  log(message);
  }

  public void attributeRemoved(ServletContextAttributeEvent p0)
  {
  }

  public void attributeReplaced(ServletContextAttributeEvent p0)
  {
	  String message = "Attribute replaced name is: " + p0.getName() + " value is: " + p0.getValue().toString();
	  log(message);
  }
  
	public void attributeRemoved(HttpSessionBindingEvent arg0) {
		String message = "";
		message += "attributeRemoved: ";
		message += arg0.getName() + "=" + arg0.getValue().toString() + "  :  ";
		message += "Session id = " + arg0.getSession().getId();
		log(message);
	}
	public void attributeReplaced(HttpSessionBindingEvent arg0) {
		String message = "";
		message += "attributeReplaced: ";
		message += arg0.getName() + "=" + arg0.getValue().toString() + "  :  ";
		message += "Session id = " + arg0.getSession().getId();
		log(message);
	}
	public void sessionDestroyed(HttpSessionEvent arg0) {
		String message = "";
		message += "sessionDestroyed: ";
		message += "Session id = " + arg0.getSession().getId();
		log(message);
	}

	public void sessionCreated(HttpSessionEvent arg0) {
		String message = "";
		message += "sessionCreated: ";
		message += "Session id = " + arg0.getSession().getId();
		log(message);
	}

	public void attributeAdded(HttpSessionBindingEvent arg0) {
		String message = "";
		message += "attributeAdded: ";
		message += arg0.getName() + "=" + arg0.getValue().toString() + "  :  ";
		message += "Session id = " + arg0.getSession().getId();
		log(message);
	}

	private void log(String message) {

		System.err.println(message + " ; " + new java.util.Date());
	}
	
	public void contextInitialized(ServletContextEvent arg0) {
		System.err.println("Servlet Context Initialized");
	}
	
	public void contextDestroyed(ServletContextEvent arg0) {
		System.err.println("Servlet Context Destroyed");
	}
}