package simple.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.PrintWriter;
import java.io.IOException;

public class CounterServlet extends HttpServlet {
	/**
	 *  
	 */
	private static final long serialVersionUID = 1L;

	private static final String CONTENT_TYPE = "text/html";

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType(CONTENT_TYPE);
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(true);
		String sessionid = session.getId();
		Integer sessionCount = (Integer) session.getAttribute("sessionCount");
		if (sessionCount == null) {
			sessionCount = new Integer(0);
		} else {
			sessionCount = new Integer(sessionCount.intValue() + 1);
		}
		session.setAttribute("sessionCount", sessionCount);
		out.println("<html>");
		out.println("<head><title>CounterServlet</title></head>");
		out.println("<body>");
		out.println("<p>Number of requests for the session with the id of "
				+ "<b>" + sessionid + "</b> is: " + sessionCount);
		out.println("</body></html>");
		out.close();
	}
}
