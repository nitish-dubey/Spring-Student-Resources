package simple.servlet;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class StateServlet extends HttpServlet {
  int counter = 0;
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    out.println ("<html>");
	out.println("<head><title>State Servlet Example</title></head>");
    out.println ("<body>");
    out.println ("Page accessed " + counter++ + "  times");
    out.println ("</body></html>");
  }
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
  }
}
