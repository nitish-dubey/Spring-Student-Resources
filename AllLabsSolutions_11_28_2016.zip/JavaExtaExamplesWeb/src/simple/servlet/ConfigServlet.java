package simple.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ConfigServlet extends HttpServlet {

public void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException { 
		ServletConfig config = getServletConfig();
		String company = config.getInitParameter("company");
		String location = config.getInitParameter("location");
		PrintWriter out = resp.getWriter();
		out.print("Initialization parameters <BR>");
		out.print(company + " " + location + "<BR>");

		out.print("<BR>Context Parameters <BR>");
		ServletContext context = config.getServletContext();
		Enumeration names = context.getInitParameterNames();
		while (names.hasMoreElements()) {
			String name = (String) names.nextElement();
			String value = context.getInitParameter(name);
			out.print(name + "=" + value + "<BR>");
		}

	 }

}