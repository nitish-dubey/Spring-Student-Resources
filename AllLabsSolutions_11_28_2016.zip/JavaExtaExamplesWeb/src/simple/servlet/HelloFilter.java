package simple.servlet;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class HelloFilter implements Filter 
{ 
private FilterConfig filterConfig = null; 
int cnt = 0; 

public void init(FilterConfig filterConfig) throws ServletException 
{ 
   this.filterConfig = filterConfig; 
   System.out.println("Filter Initialized"); 
} 

public void destroy() 
{ 
   this.filterConfig = null; 
} 

public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
{ 
   System.out.println("Hello From Filter "+  (cnt++)); 

   chain.doFilter(request, response); 
   System.out.println("Exiting Filter "+ (--cnt)); 
} 
} 




