package simple.servlet;

import java.io.IOException;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ResponseServlet extends HttpServlet {

	public void doGet(HttpServletRequest arg0, HttpServletResponse arg1)
			throws ServletException, IOException {

//		arg1.sendError(HttpServletResponse.SC_NOT_FOUND);
		String url = "http://www.learnquest.com";
		arg1.sendRedirect(url);
	}

}