package simple.tag;
import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;

public class HelloName extends TagSupport 
{
  /*
  tag attribute: name
  */

  private String name = "";


  /**
   * Method called at start of tag.
   * @return SKIP_BODY
   */
  public int doStartTag() throws JspException
  {
    try
    {
      JspWriter out = pageContext.getOut();
      out.println("Hello " + name);
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    return SKIP_BODY;
  }


  /**
   * Method called at end of tag.
   * @return EVAL_PAGE
   */
  public int doEndTag()
  {
    return EVAL_PAGE;
  }


  public void setName(String value)
  {
    name = value;
  }


  public String getName()
  {
    return name;
  }
}